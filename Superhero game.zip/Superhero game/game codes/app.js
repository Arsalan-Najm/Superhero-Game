//access to the canvas and other content
const cvs = document.getElementById("canvas");
const ctx = cvs.getContext("2d");
const scoreText = document.getElementById("score");
const container = document.querySelector(".over");
const gold = document.querySelector(".gold");
const silver = document.querySelector(".silver");
const bronze = document.querySelector(".bronze");
const noRank = document.querySelector(".no-rank")
//Images object
const background = new Image();
const heroImage = new Image();
const north = new Image();
const south = new Image();
//Images content  
background.src = "C:/Users/Arsalan-Najm/Desktop/All Stuff/All tests/Superhero game/images/bg.jpg";
heroImage.src = "C:/Users/Arsalan-Najm/Desktop/All Stuff/All tests/Superhero game/images/hero.png";
north.src = "C:/Users/Arsalan-Najm/Desktop/All Stuff/All tests/Superhero game/images/north.png";
south.src = "C:/Users/Arsalan-Najm/Desktop/All Stuff/All tests/Superhero game/images/south.png";
//Audio object
const backgroundSound = new Audio();
const falling = new Audio();
//Audio content
backgroundSound.src = "C:/Users/Arsalan-Najm/Desktop/All Stuff/All tests/Superhero game/audio/flying.mp3";
falling.src = "C:/Users/Arsalan-Najm/Desktop/All Stuff/All tests/Superhero game/audio/falling.mp3";
//The gap and spacing between two bulidings
const gap = 310;
const spacing = north.height+gap;
//X and Y position of superhero + gravity where hero falls down
var sX = 10;
var sY = 100;
var gravity = 5;
//Moving the hero
document.addEventListener("keydown",moveNum2);
function moveNum2(e) {
	const key = e.keyCode;
	if(key === 38 || key === 87) {
		sY -= 50
	}
}
document.addEventListener("click",move);
function move() {
	sY -= 50
}
//Score of the game
let score = 0;
//Array which creates different buildings with different positions
let  building = [];
building[0] = {
	x: cvs.width,
	y: 0,
};
//Game functionalily
function draw() {
		ctx.drawImage(background,0,0,);
	for(var i=0; i<building.length; i++) {
			ctx.drawImage(north,building[i].x,building[i].y);
	        ctx.drawImage(south,building[i].x,building[i].y+spacing);
	        building[i].x--;
	        if(building[i].x == cvs.width - 230) {
	        	building.push({
	        		x: cvs.width,
	        		y: Math.floor(Math.random() * north.height) - north.height,
 		     	});
	        }
	        backgroundSound.play();
	        if(sY > cvs.height - 35 ) {
	        	clearInterval(game);
	        	falling.play();
	        	backgroundSound.pause();
	        	container.classList.add("active");
	        	scoreText.innerHTML = score;
	        }
	        if(building[i].x + 80 == sX){
	        	score++;
    	    }
    	    if(score < 4) {
    	    	noRank.classList.add("show");
    	    }
    	    if(score > 0) {
    	    	bronze.classList.add("show");
    	    	noRank.classList.remove("show");
    	    }
    	    if(score > 4) {
    	    	silver.classList.add("show");
    	    	bronze.classList.remove("show");
    	    }
    	    if(score > 7) {
    	    	gold.classList.add("show");
    	    	silver.classList.remove("show");
    	    }
	}
//Score text 
    	    ctx.fillStyle = "#fff";
    	    ctx.font = "40px montserrat,sans-serif";
    	    ctx.fillText(score,150,42);

    	    ctx.fillStyle = "#fff";
    	    ctx.font = "40px montserrat,sans-serif";
    	    ctx.fillText("score:",20,40);
//Load superhero Image
	ctx.drawImage(heroImage,sX,sY);
//How hero falls to the ground 
	sY += gravity;
}
//Game frame per seconds
let game = setInterval(draw,30);